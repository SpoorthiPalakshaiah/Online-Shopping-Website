-- phpMyAdmin SQL Dump
-- version 4.8.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 09, 2018 at 09:49 AM
-- Server version: 10.1.34-MariaDB
-- PHP Version: 7.2.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `square`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `name` varchar(10) NOT NULL,
  `password` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`name`, `password`) VALUES
('Chinni', 'chinni'),
('Riya', 'riya'),
('Spoorthi', 'spoorthi');

-- --------------------------------------------------------

--
-- Table structure for table `company`
--

CREATE TABLE `company` (
  `name` varchar(20) NOT NULL,
  `phoneno` bigint(11) NOT NULL,
  `address` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `company`
--

INSERT INTO `company` (`name`, `phoneno`, `address`) VALUES
('Daniel Hechter', 9448856970, 'Daniel Hechter Boutique in Indira Nagar, Bangalore'),
('Dressberry', 9448665415, ' 65 Nehru Nagar, Near Radha Krishna Temple, Agra '),
('Flying Machine', 9845493539, 'Du Parc Trinity, 8th Floor,17 M.G Road,Bengaluru'),
('Jules', 9886693362, 'Jules Verne 96 Great Suffolk Street London'),
('Mango', 9164595177, 'Mango Store,Phoenix Market City Bengaluru'),
('Numero Uno', 9845493539, ' ParasTrade Centre,6th Floor,Gwal Pahari,Faridabad'),
('Pepe Jeans', 9164595177, '3rd floor \'C\' wing,Corporate office, Chakala'),
('Provogue', 9731331269, '105/106,Provogue House,OffLink Road,Andheri,Mumbai'),
('Roadster', 9845493539, '777/A, HAL 2nd Stage,13th main Road,Bengaluru'),
('The House of Mayra', 9886682263, 'Mayra and Khatri,Opera House,Mumbai-400004'),
('Zara', 9739944707, 'Phoenix market city,142,Velachary main road,Mumbai');

-- --------------------------------------------------------

--
-- Table structure for table `dress`
--

CREATE TABLE `dress` (
  `dresscode` int(11) NOT NULL,
  `name` varchar(250) NOT NULL,
  `price` float NOT NULL,
  `description` varchar(2000) NOT NULL,
  `size` varchar(2) NOT NULL,
  `color` varchar(11) NOT NULL,
  `image` text NOT NULL,
  `cname` varchar(20) NOT NULL,
  `category_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `dress`
--

INSERT INTO `dress` (`dresscode`, `name`, `price`, `description`, `size`, `color`, `image`, `cname`, `category_id`) VALUES
(10000001, 'A blue casual kurti', 999, 'This kurti which is made from cotton fabric is blue in color.This kurti has been designed keeping in mind the latest trends in contemporary casual fashion.', 'L', 'Blue', 'kt-1.jpg', 'Numero Uno', 1),
(10000002, 'A day-dreamy kurti', 499, 'This kurti is stylish and made of cotton having a bell sleeves and is better option for nice family function.', 'L', 'Blue', 'kt-2.jpg', 'Daniel Hechter', 1),
(10000003, 'A casual cut-out kurti', 699, 'This is designed as per the latest trends to keep you in sync with high fashion it will keep you comfortable all day long.', 'L', 'Yellow', 'kt-3.jpg', 'Mango', 1),
(10000004, 'A desi blue kurti', 999, 'Flaunt sartorial elegance as you wear this kurti.Look classy and stylish in this piece and reveal in the comfort of the soft fabric.', 'L', 'Blue', 'kt-4.jpg', 'Mango', 1),
(10000005, 'Front slit trendy kurti', 999, 'This has a round neck,full sleeves and a front slit.This Indian kurti is constructed with fine quality crepe fabric that flatters.', 'L', 'Red', 'kt-5.jpg', 'Jules', 1),
(10000006, 'A printed tunic', 499, 'March out in full confidence of the fashion forwardness that this desirable curiously contemporary kurti brings to your humble wardrobe giving an elegant look.', 'L', 'Blue', 'kt-6.jpg', 'Flying Machine', 1),
(10000007, 'A stylish tunic', 599, 'This tunic has been designed keeping in mind the latest trends in contemporary casual fashion.The garment combines style with the fashion of today and makes you stand out among others when you adorn it.', 'L', 'Blue', 'kt-7.jpg', 'Flying Machine', 1),
(10000008, 'A semi traditional tunic', 899, 'Crafted from cotton fabric, it is light in weight and will be soft against your skin.Its unique design and beautiful color will fetch a lot of second glances as you club it with contrast colored pumps and flashy accessory', 'L', 'Orange', 'kt-8.jpg', 'Flying Machine', 1),
(10000010, 'Green checkered tunic', 499, 'Trendy and appealing,this tunic will surely impress fashionable women.This will surely add unique charm to your casual as well as party look.Made from quality fabric,this will also help you stay relaxed all day long.', 'L', 'Green', 'kt-10.jpg', 'Daniel Hechter', 1),
(11000001, 'High waist pink skirt', 799, 'This is a widely used accessory for girl in the modern days,it fits to any kind of your clothes.It can be used as a skirt or a tube top,both way is beautiful.', 'M', 'Pink', '11-4.jpg', 'Daniel Hechter', 11),
(11000002, 'Flared skater short skirt', 1199, 'Skater skirts are the perfect wardrobe essential to wear all year round.This skirt features an elastic waistband and a paneled construction. ', 'L', 'Green', '11-1.jpg', 'Daniel Hechter', 11),
(11000003, 'A denim mini skirt', 899, 'This slim fit denim skirt is fully fashionable hence will make you look beautiful hot and will also keep you in sync with this fashion world.', 'M', 'Blue', '11-3.jpg', 'Roadster', 11),
(11000004, 'Women\'s crape short skirt', 799, 'If you like experimenting with your look and clothes then this skirt is not to be missed.This is a great style for anyone who likes the skirts look but wants to maintain a little modesty.', 'L', 'White', '11-12.jpg', 'Dressberry', 11),
(11000005, 'Short mesh ruffle mini skirt', 899, 'Made from exclusive designed clothing.It gives you astonishing look of shade black.Connected Nylon Elastics and a knot with skirt adds to extra charming look.Perfect for party lovers with the taste for fashion.', 'L', 'Black', '11-13.jpg', 'Daniel Hechter', 11),
(11000006, 'Women\'s pleated skirt', 799, 'This sky blue colored skirt has beautiful frills and a trendy look.The freshness of the color and the buttons with a nylon waist band adds to its elegance.', 'L', 'Blue', '11-2.jpg', 'Roadster', 11),
(11000007, 'Blue frayed denim shorts', 699, 'These midrise distressed denim shorts are perfect for this summer as it is lightweight with soft denim material for comfort all day long.', 'L', 'Blue', '11-5.jpg', 'Roadster', 11),
(11000008, 'Orange hot shorts', 799, 'These regular fit denim shorts are perfect for parties and the unique orange color makes it look extremely hot.', 'L', 'Orange', '11-10.jpg', 'Roadster', 11),
(11000009, 'Light blue denim ripped shorts', 899, 'Fashionable women will never fail to impress people around them wearing something as stylish as this pair of light blue colored casual solid shorts.', 'L', 'Blue', '11-6.jpg', 'Roadster', 11),
(11000010, 'Solid shorts with a waist belt', 999, 'Elevate your style this season with a pair of stylish shorts.This solid creamy shorts with a floral kind of print and a waist belt giving it a add on beauty.', 'L', 'Cream', '11-15.jpg', 'Daniel Hechter', 11),
(12000001, 'Knitted tassel jacket', 1499, 'This irregular knitted top tassel sweater cardigan has a vintage ethic pullover look with a regular closure sleeve and polyester cloak material with a deep V neck pattern.', 'M', 'Grey', '12-2.jpg', 'Flying Machine', 12),
(12000002, 'Long floral Shrug', 599, 'This gorgeous shrug with floral design and a tie-knot at the front is simply irresistible for modern women.The georgette fabric makes it soft and comfortable to wear.', 'L', 'Cream', '12-5.jpg', 'Provogue', 12),
(12000003, 'Knitted blanket shrug', 1255, 'If you are hunting for a knitted jacket pattern you will love this.This white knitted shrug goes along in any occasion and is also well versed for winter too.', 'M', 'White', '12-3.jpg', 'Jules', 12),
(12000004, 'Woolen Pink Dazzler', 799, 'This woolen pink dazzle with woolen fabric is very suitable for winter and can get along with any color of jeans.', 'M', 'Pink', '12-18.jpg', 'Jules', 12),
(12000005, 'Cream shrug with lace trim', 999, 'This beautiful cream chiffon fabric bolero short shrug is perfect for covering the shoulders which has a lace trim all over.', 'L', 'Cream', '12-7.jpg', 'The House of Mayra', 12),
(12000006, 'Long Grey shrug', 499, 'A full sleeves long grey shrug with casual coverup georgette top and it is a versatile cardigan.', 'L', 'Grey', '12-6.jpg', 'Jules', 12),
(12000007, 'Cream chic boutique jacket', 2800, 'It has a paper sewing pattern to make a vintage inspired jacket and has a frieda shawl collar which can go along in the formal occasions too.', 'M', 'Brown', '12-9.jpg', 'Roadster', 12),
(12000008, 'A cream waterfall shrug', 799, 'A cream 3/4th sleeve shrug with waterfall structure jacket which can get along in any kind of occasion and also be used in winters as sweaters.', 'L', 'Cream', '12-1.jpg', 'The House of Mayra', 12),
(12000009, 'Sleeve sheet ivory jacket', 999, 'The 3/4th sleeve off bolero jacket is light weight and loose. It is perfect for any formal gatherings and also for cocktail parties.', 'L', 'Grey', '12-4.jpg', 'Pepe Jeans', 12),
(12000010, 'Winter fur quilted jacket', 3599, 'Long sleeve fur quilted jacket with detachable hoodie to keep yourself cozy with maximum comfort', 'L', 'Brown', '12-11.jpg', 'Daniel Hechter', 12),
(12000011, 'Stunning upcycle jean jacket', 999, 'Embellished with vintage and banjara tribal gypsy tassel with brightly patched designs.', 'L', 'Blue', '12-15.jpg', 'Daniel Hechter', 12),
(12000012, 'Butterfly patches denim jacket', 999, 'Blue non stretch denim jacket with light wash finish,classic point collar with button placket and embroidered pockets.', 'L', 'Blue', '12-16.jpg', 'Roadster', 12),
(12000013, 'Pearl embellished jean jacket', 799, 'Beading,vintage,buttons, pockets and solicked frayed clothing with turn down collar.', 'L', 'Blue', '12-17.jpg', 'Roadster', 12),
(12000014, 'Winter wool blend hooded coat', 1255, 'The cloak coat featuring solid color,cape style and hooded looks extremely beautiful and go along well in any occasion.', 'L', 'Cream', '12-22.jpg', 'Daniel Hechter', 12),
(20000001, 'Printed Palazzo set', 1255, 'This beautiful dress maintain an elegant look all year long.This kurta has fit and flare fashion and has 3/4th sleeves.', 'M', 'Blue', 'ed-1.jpg', 'Daniel Hechter', 2),
(20000002, 'Blossom dhoti kurta', 799, 'For all those who love to dress up in a chic and trendy style,this kurta comes with a designer above knee length.It has a waterfall sleeve pattern and comes with designer crepe dhoti pant.', 'M', 'Yellow', 'ed-2.jpg', 'Daniel Hechter', 2),
(20000003, 'A dhoti ethnicity', 4599, 'Designed with absolute perfection,this slub dhoti set will capture your hearts with its traditional ethnicity and make you look fashionable and trendy.', 'L', 'Cream', 'ed-3.jpg', 'Daniel Hechter', 2),
(20000004, 'A long ethnic dress set', 1599, 'Soar to the new level of fashion with this alluring ethnic set.It comes with a delightful long jacket style kurta along with a pair of contrast-toned parallel pants.', 'M', 'Yellow', 'ed-4.jpg', 'Mango', 2),
(20000005, 'A black dhoti set', 1299, 'If you are looking for  a unique pattern in your wardrobe and  a highly stylised set then this set has the answer for you.', 'M', 'Black', 'ed-5.jpg', 'Mango', 2),
(20000006, 'Golden chic ethnic wear', 3799, 'It features sleeveless kurta with a embroidery jacket,indo western and it is a ankle length kurta with a embroidered pants that is suitable for festive occasions and give a chic look.', 'L', 'Cream', 'ed-6.jpg', 'Daniel Hechter', 2),
(20000007, 'Royal kurta sharara set', 2799, 'This beautiful party wear kurta with royal sharara palazzo set will help you maintain an elegant look all year long. ', 'L', 'Blue', 'ed-7.jpg', 'Daniel Hechter', 2),
(20000008, 'Sky blue embroidered sharara suit', 2699, 'It features a georgette kameez with georgette sharara with netted dupatta.Embroidery work is completed with thread work,lace and stone embellishments.', 'M', 'Blue', 'ed-8.jpg', 'Daniel Hechter', 2),
(20000009, 'Palazzo saree style ethnic set', 2999, 'Palazzo saree with attached dupatta to drape in your style to look like the trendiest diva where tradition meets comfort.', 'L', 'Blue', 'ed-9.jpg', 'Daniel Hechter', 2),
(20000010, 'Elegant ethnic set', 3599, 'Spruce up your ethnic collection this season with this stylish palazzo with a crop top and a embroidered jacket with contrasting colors giving a elegant festive look.', 'M', 'Cream', 'ed-10.jpg', 'Daniel Hechter', 2),
(30000001, 'Ethnic junction dress', 799, 'This classy patiala kurta radiates oodles of charm.You will agree when we mention-this kurta boasts of a modern design and exudes a chic appeal.The color combination and printed bottom makes this patiala a delectable dress.', 'L', 'Cream', 'dc-1.jpg', 'Flying Machine', 3),
(30000002, 'An exclusive salwar kurta', 799, 'The dress is made of soft, premium quality crepe material.The gorgeous rich texture of the dress enhances the design. ', 'L', 'Green', 'dc-2.jpg', 'Dressberry', 3),
(30000003, 'Double colored chudidar', 1199, 'This is made from cotton and has double shades of green.This fabric has been designed keeping in mind the latest trends in ethnic and casual wear.', 'L', 'Green', 'dc-3.jpg', 'Jules', 3),
(30000004, 'An Ethnic Elegant dress', 799, 'This dress is an ideal choice when you are choosing the right fabric for your ethnic wear.This dress is made from polyester and is available in a shade of red black.', 'L', 'Red', 'dc-4.jpg', 'Jules', 3),
(30000005, 'Rama Green chudidar', 899, 'This dress is stylish,trendy and unique!This design is for ethnicwear multipurpose collection and can be worn in any event.', 'L', 'Green', 'dc-5.jpg', 'Dressberry', 3),
(30000006, 'An off-white gown dress', 1599, 'This dress is stylish,comfortable and great value for money.A worthy addition to your ethnic wardrobe created from the finest soft Tafeta silk and netted fabric,to offer you comfort and style.', 'L', 'White', 'dc-6.jpg', 'Jules', 3),
(30000007, 'A red hot umbrella dress', 1399, 'This dress is made of georgette.It is a light-weighted,crinkled and sheer umbrella dress displaying an overall bouncy look.', 'L', 'Red', 'dc-7.jpg', 'Jules', 3),
(30000008, 'Ethnic silk dress', 1599, 'This dress has an essence of traditions and yet they are forward looking and contemporary.Bright to subtle,simply wear to party pick.', 'L', 'Green', 'dc-8.jpg', 'Dressberry', 3),
(30000009, 'A designer exquisite dress', 2999, 'Designed with absolute perfection,this dress will capture your hearts with its design.Look classy and stylish in this piece and reveal in the comfort of fabric.This apparel will make you look stunning and ravishing.', 'L', 'Green', 'dc-9.jpg', 'Dressberry', 3),
(30000010, 'Maxi long dress with jacket', 1799, 'This beautiful dress which is made from a synthetic polyster and cotton,which features an attached jacket giving the dress a special look and feel.', 'L', 'Red', 'dc-10.jpg', 'Dressberry', 3),
(40000001, 'Pink long Skirt', 799, 'This skirt is soft and solid that looks perfect for regular wear.With beautiful designs and patterns, this apparel is very stylish and comfortable too.', 'L', 'Pink', 's1.jpg', 'Dressberry', 4),
(40000002, 'A printed skirt', 799, 'Flaunt your style wearing this long skirt made of cotton.This regular fit skirt ensures utmost comfort all day long and is easy to maintain.', 'L', 'Blue', 's2.jpg', 'Mango', 4),
(40000003, 'A ghera long skirt', 499, 'Red colored solid ghera  skirt,featuring regular fit,full length and elasticated waist band with drawstrings for easy functioning.', 'L', 'Red', 's3.jpg', 'Jules', 4),
(40000004, 'Traditional blue skirt', 799, 'Flaunt your style wearing this long skirt made of cotton silk.This regular fit skirt ensures utmost comfort all day long and can get along well on any festives.', 'L', 'Blue', 's4.jpg', 'Dressberry', 4),
(40000005, 'Hand beaded sequin skirt', 599, 'Features with metallic work with a elastic waistband.This give an ethnic look to your personality.Embellished with numerous iridescent silver sequins with a slight print. ', 'L', 'Red', 's5.jpg', 'Flying Machine', 4),
(40000006, 'Rayon blue palazzo', 699, 'Palazzo pant refers to a loose-fitting outergarment for the lower part of the body.Be ready in this uber comfortable Premium palazzo and rule the world.', 'L', 'Blue', 'p2.jpg', 'Dressberry', 4),
(40000007, 'A floral print palazzo pants', 699, 'Double your fashion flair and flaunt your new and refreshing look this season with these printed palazzo pants.', 'L', 'White', 'p3.jpg', 'Dressberry', 4),
(40000008, 'Broad dotted palazzo', 699, 'Add pizzazz to your look as you wear this palazzos.Designed for fashion-forward women,these pants will become one of your favorites this season.', 'L', 'Blue', 'p4.jpg', 'Jules', 4),
(40000009, 'A Chic semi-formal palazzo', 999, 'This is made in best quality fabric and very comfortable to wear and can be paired with kurti a s well as tops to give a semi-formal look.Designed to perfection,these chic trousers are a must-buy!', 'L', 'Yellow', 'p5.jpg', 'Jules', 4),
(40000010, 'Crepe stylish palazzo', 799, 'Palazzo trousers are popular as a summer season style,as they are loose and tend to be flattering in light,flowing fabrics that are breathable in hot weather.', 'L', 'Blue', 'p1.jpg', 'Jules', 4),
(50000001, 'Beautiful Blue Saree', 2699, 'This saree is elegantly crafted and will surely add to your wardrobe.Pair this piece with heels or flats for a graceful look.', '', 'Blue', '5-1.jpg', 'Zara', 5),
(50000002, 'Grey festival wear saree', 3679, 'Look stunning and classy with this saree.The saree is made from art silk and is grey in color with combination of pink blouse looking extremely elegant.', '', 'Grey', '5-5.jpg', 'Zara', 5),
(50000003, 'Classic yet quirky blouse', 599, 'Readymade saree blouse is made of premium quality cotton lycra.This blouse is highly comfortable and a perfect pick for any season', '', 'Black', '5-12.jpg', 'Dressberry', 5),
(50000004, 'Dark blue silk saree', 3999, 'This elegant saree which help in adding an essence of grace in your wardrobe.These sarees come in assorted colors and appealing designs which make them ideal for various occasions.', '', 'Blue', '5-7.jpg', 'Zara', 5),
(50000005, 'A pattu saree blouse', 1999, 'This blouse comes with 3/4th sleeves and unique style which is having contrasting classy/solid pattern.This charming blouse will surely fetch you compliments for your rich sense of style.', '', 'Green', '5-2.jpg', 'Flying Machine', 5),
(50000006, 'Sunshine smile stills saree', 2499, 'The saree is a suitable amalgamation of style with the grace that is required from an ethnic wear.You can wear it to casual occasions as well as make it a part of your festive wear.', '', 'Yellow', '5-9.jpg', 'Zara', 5),
(50000007, 'Blue cotton silk saree', 1659, 'Flaunt your ethnic facade by draping yourself in this beautiful cotton silk saree. Displaying a play of metallic and vibrant colors,this singular piece promises to lend an elegant and sophisticated look.', '', 'Blue', '5-8.jpg', 'Zara', 5),
(50000008, 'Elegant rose saree', 3999, 'The saree has been designed keeping in mind the latest trends in fashion when it comes to dressing up at party with a unique blouse pattern.', '', 'Pink', '5-3.jpg', 'Zara', 5),
(50000009, 'Neck embroidery red blouse', 699, 'A versatile traditional blouse is almost a must-have in your wardrobe.This blouse is readymade and easy to wear.The design contributes to the elegance of the blouse.', '', 'Red', '5-10.jpg', 'Flying Machine', 5),
(50000010, 'Stunning design blouse', 599, 'This gorgeous-looking blouse really embelishes your look.It accentuates your ethnic look and makes you look fantastic.This blouse makes a great selection for any upcoming occasion.', '', 'Blue', '5-13.jpg', 'Dressberry', 5),
(50000011, 'Designer white Saree', 1199, 'This saree is off-white in color with a contrasting blouse.The saree has been designed keeping in mind the latest trends in fashion when it comes to dressing up at festivals or at casual evenings.', '', 'White', '5-4.jpg', 'The House of Mayra', 5),
(50000012, 'Pink pure cotton silk saree', 1499, 'This saree is made from chanderi cotton and is pink in color.It displays a stunning work and will be extremely comfortable to wear and makes you spotting and iconic like never before.', '', 'Pink', '5-6.jpg', 'Zara', 5),
(50000015, 'Raw silk designer blouse', 699, 'A simple,modern blouse is what we all desire in our wardrobe.This blouse is readymade and easy to wear.The paisley design contributes to the elegance of the blouse,while the trendy back cut makes it alluring.', '', 'Blue', '5-11.jpg', 'Zara', 5),
(60000001, 'Global style lehenga', 2499, 'Step into enchanted territory as we invite you to explore the language of desi texture with this beautiful lehenga details,ruffles,colors and electro style.', 'L', 'Orange', '6-5.jpg', 'The House of Mayra', 6),
(60000002, 'Velvet lehenga Choli', 2999, 'Get amazed by the ethnic heavy work at the clothing which adds a sign of attractiveness statement with your look.', 'L', 'Blue', '6-10.jpg', 'Jules', 6),
(60000003, 'Crepe lehenga Choli', 1499, 'Spruce up your ethnic collection this season with this stylish lehenga choli.Team your set with heels or flats for an elegant look.', 'L', 'Pink', '6-4.jpg', 'The House of Mayra', 6),
(60000004, 'Embroidery lehenga', 1255, 'This designer embroidery taffeta lehenga is in a elegant shade.And is suitable choice when it comes to choosing an ethnic wear or a festive wear for your wardrobe.', 'L', 'Pink', '6-3.jpg', 'Dressberry', 6),
(60000005, 'Half saree lehenga', 2300, 'This half saree lehenga will enhance the beauty of the women which can be worn for functions,festivals,parties and even weddings too.', 'L', 'Green', '6-1.jpg', 'The House of Mayra', 6),
(60000006, 'Banarasi silk lehenga', 1799, 'The hottest trend of this season,this woven banarasi lehenga lends both sober and a sophesticated look.The dupatta is in georgette looking amazingly beautiful. ', 'L', 'Blue', '6-13.jpg', 'Mango', 6),
(60000007, 'Floral print Lehenga', 1599, 'This fashionable floral print lehenga looks like a dream wearing.Look classy and stylish in this piece and reveal in the comfort of the floral print.', 'L', 'Pink', '6-7.jpg', 'The House of Mayra', 6),
(60000008, 'Eyes on me lehenga', 1999, 'The true mystery of excellent fashion and design is revealed with this exotic lehenga. You will look like a true diva in this lovely piece of lehenga.', 'L', 'Pink', '6-9.jpg', 'The House of Mayra', 6),
(60000009, 'Fashionable lacy lehenga', 3250, 'This lehenga blends contemporary themes with Indian art forms to develop surreal designs suitable for Indian body which looks extremely beautiful.', 'M', 'Cream', '6-12.jpg', 'The House of Mayra', 6),
(70000001, 'Crepe straight jumpsuit', 799, 'This jumpsuit crafted out from crepe is green in color.Look unique and smart by wearing this party wear jumpsuit .', 'M', 'Green', '7-20.jpg', 'Provogue', 7),
(70000002, 'Blue party wear jumpsuit', 999, 'This is impeccably fitted navy blue jumpsuit in smooth crepe provides a sleek and streamlined silhouette that is endlessly flattering and pairs with everything.', 'L', 'Blue', '7-19.jpg', 'Jules', 7),
(70000003, 'One shoulder jumpsuit ', 1255, 'Get a perfect look this season with this amazing jumpsuit having a one shoulder look.This jumpsuit is light in weight and comfortable to wear and the color makes it look even more elegant and beautiful.', 'L', 'Blue', '7-16.JPG', 'Flying Machine', 7),
(70000004, 'An elegant flattering dress', 599, 'This short dress with a fitted waist and a skirt that flares into an A-line shape.It is most flattering and provides cute options.You can look flaunting with this dress on a day brunch and evening out with friends.', 'L', 'Blue', '7-9.jpg', 'Flying Machine', 7),
(70000005, 'A red lacy dress', 1299, 'Pull together a chic look wearing dress crafted from laces.It will keep you comfortable throughout the party.Team it with matching pumps to step out in style.', 'L', 'Red', '7-2.jpg', 'Jules', 7),
(70000006, 'Green floral print dress', 999, 'Jet from day to night with ease wearing dress.Tailored in regular fit and flare,at this dress will keep you comfortable all day long.Team it with matching pumps to step out in style.', 'L', 'Green', '7-1.jpg', 'Mango', 7),
(70000007, 'A trendy shimmery dress', 1599, 'This trendy,stylish and fashionable dress made with fine quality imported crepe material with shimmer.This dress offers you to attract compliments by others.', 'M', 'Cream', '7-6.jpg', 'Zara', 7),
(70000008, 'White tied Dress', 799, 'Pure white lets you look more elegant, and the hollow out tie design on the dress gives people an impression of charming.', 'L', 'White', '7-10.jpg', 'Flying Machine', 7),
(70000009, 'Khaki checkered dress', 1255, 'Take a more relaxed approach towards fashion wearing these khaki colored checks dress resembling dungaree and moreover, this dress will keep you comfortable the entire day.', 'L', 'Brown', '7-11.jpg', 'Flying Machine', 7),
(70000010, 'A brown short dress', 999, 'This dress offers you to attract compliments which can be worn for functions and parties.Unique design in this dress enhances your beauty which you can carry on any parties and to complete your look.', 'L', 'Brown', '7-5.jpg', 'Jules', 7),
(80000001, 'Asymmetric stripes B-W top', 499, 'This top from exclusive collection will surely impress fashionable woman and add unique charm to your casual as well as party look', 'M', 'White', '8-1.jpg', 'Jules', 8),
(80000002, 'White & Peach t-Shirt', 399, 'It has a round neck, short sleeves.Boost your personal style with thus one-of-a-kind top which is comfortable and fashionable too.', 'M', 'White', '8-2.jpg', 'Mango', 8),
(80000003, 'A Pearly tizzy top', 999, 'This top has quality fabrics and flattering styles and fits,this top have a pearl beading that are priced to look extremely beautiful and stylish.', 'M', 'Red', '8-3.jpg', 'The House of Mayra', 8),
(80000004, 'A pearled dark top', 1159, 'Engineer a smart casual look this weekend wearing this stylish colored top,which will stay extremely soft against your skin. ', 'M', 'Red', '8-4.jpg', 'Jules', 8),
(80000005, 'Indo-Westy green top.', 799, 'This is made of fine quality cotton fabric,with cut-work/self-design for ultimate comfort style.This top will set your fashion trends.', 'M', 'Green', '8-5.jpg', 'Provogue', 8),
(80000006, 'Cute but Psycho', 599, 'This round neck crop top is a great basic piece to own.Pair it with skinny jeans and dressy flats for a fun-day look.', 'M', 'Black', '8-8.jpg', 'Provogue', 8),
(80000007, 'Netted sleeves top', 799, 'Trendy,appealing and exclusive. Made from crepe,this top will help you look stylish and fashionably elegant.', 'M', 'White', '8-9.jpg', 'Provogue', 8),
(80000008, 'Casual chic checks top', 699, 'Make the girls go as you wear. This top is designed as per the latest trends giving trendy look and fashioned using quality fabrics.', 'M', 'Red', '8-10.jpg', 'Jules', 8),
(80000009, 'Black off-shoulder top', 1255, 'This ruffle chic chocker neck off-shoulder top is designed as per the trends and fashioned.This beautiful creation will give you a fashionable and modish look.', 'M', 'Black', '8-11.jpg', 'Mango', 8),
(80000011, 'Street style lush top', 999, 'This top symbolizes wide range of smart updated tops which are appropriate for both work and play.Look amazing and flaunt style with this top.', 'M', 'Cream', '8-15.jpg', 'The House of Mayra', 8),
(80000012, 'Turtled neck ruffle top', 1159, 'This trending top with ruffles and full sleeves makes it one of the best in wardrobe. Easy to wear top on any occasion.', 'M', 'White', '8-19.jpg', 'Mango', 8),
(90000001, 'Casual blue Denims ', 599, 'Impress everyone with your stunning casual look wearing these blue jeans.Featuring an elasticated waistband for a snug fit,these regular-fit,mid-rise jeans are apt for all those casual outings with friends.The cotton spandex fabric further ensures maximum comfort', 'L', 'Blue', '9-1.jpg', 'Provogue', 9),
(90000002, 'Stylish Dark blue denims', 699, 'Look Stylish and shapely by wearing these jeans for women. Made from a Cotton Stretch Denim.These jeans gives you a stylish and comfortable look.You can team these jeans with a top of your choice to look fashionable and trendy.', 'M', 'Blue', '9-3.jpg', 'Dressberry', 9),
(90000003, 'Slim-fit Black Denim Jeans', 999, 'Look simply sexy in the casual attire by wearing these black colored jeans.These slim-fit jeans offer you a perfect fit with great comfort throughout.These jeans can be paired with a casual shirt or a top for a flawless look', 'L', 'Black', '9-4.jpg', 'Mango', 9),
(90000004, 'Super Rip blue denim jeans', 1255, 'Skin tight and high rise with a retro tingled silhouette made for the fashion brave.Crafted in a spray on skinny fit the killer style comes with back pockets and the rip features with a polyester and cotton fabric.', 'L', 'Blue', '9-5.jpg', 'Roadster', 9),
(90000005, 'Dark blue ripped Jeans', 1500, 'Feel comfort by wearing these jeans,these jeans give you a stylish and comfortable look because of the rip in it.You can pair these jeans with a top of your choice to look fashionable and trendy.Give girl a right jeans and she can conquer the world', 'L', 'Blue', '9-6.jpg', 'Roadster', 9),
(90000006, 'Dassler slim fit light blue denim', 799, 'Get this pair of tinted blue colored jeans which is an essential accessory in the wardrobe of every woman.Crafted out of superior quality cotton material, it is an excellent blend of comfort and style.Featuring a solid pattern, these jeans will fetch you oodles of compliments. ', 'L', 'Blue', '9-7.jpg', 'Jules', 9),
(90000007, 'Botanical embroidery blue jeans', 1499, 'It is breathtaking as a botanical garden in this pair of skinny jeans which is styled with floral embroidery side seams, distressing at front, contrast stitching.', 'L', 'Blue', '9-9.jpg', 'Jules', 9),
(90000008, 'Blue denim with embroidery stretchable jegging', 799, 'Jeggings refers to the mixture of Jeans and leggings and are designed in such a way that it is comfortable to wear.Ankle length slim fit denim with a embroidery at the side makes it a perfect look.', 'L', 'Blue', '9-10.jpg', 'Dressberry', 9),
(90000009, 'High waisted stretchable whitish jeggings', 699, 'Super fine Jeggings with stylish front buttons. You can wear it with stylish tops,T-shirts and shirts. It can fit your legs perfectly because it is super stretchable fine fabric jeggings.', 'L', 'White', '9-11.jpg', 'Dressberry', 9),
(100000001, 'Pencil fit cigarette trousers', 599, 'An amazing range of women pants and trousers in soft and solid color looks perfect for regular wear.These apparels are very stylish and comfortable too.', 'M', 'Yellow', '10-1.jpg', 'Numero Uno', 10),
(100000002, 'Waist wide leg trousers', 799, 'This black and white striped mid rise trousers have partially elasticated waist band and gives an amazing look', 'M', 'Black', '10-2.jpg', 'Dressberry', 10),
(100000003, 'A pinkish belted trouser', 999, 'Enhance your elegance with trousers.The front belt closure allows it worn with utmost comfort.Half elasticated waistband makes you feel relaxed in every occasion.', 'L', 'Pink', '10-4.jpg', 'Numero Uno', 10),
(100000004, 'Fashion tomboy trousers', 999, 'This fall\'s trousers,provide the best fabric with expert stitches,making it a genuine product at fair affordable prices with excellent quality.', 'L', 'Brown', '10-5.jpg', 'Daniel Hechter', 10),
(100000005, 'High waist peg trousers', 799, 'It is fabricated in cotton to provide you comfort and beat the heat.This white Capri is elasticized at the waist.They also come with two side pockets allowing you to keep your essential items together.', 'L', 'White', '10-6.jpg', 'Daniel Hechter', 10),
(100000006, 'A trendy fall\'s trouser', 699, 'A style composed of character,substance and determination presented in a stylish and elegant way.', 'L', 'Cream', '10-7.jpg', 'Dressberry', 10),
(100000007, 'Regular fit grey trousers', 599, 'Grey solid mid-rise cropped cigarette trousers,has a partially elasticated waistband concealed with pockets.', 'L', 'Grey', '10-8.jpg', 'Daniel Hechter', 10),
(100000008, 'Creamy casual trousers', 599, 'Showcasing formal as well as casual slub cotton trouser pants,which goes well with both the tops as well as kurtas and gives a smart and classy look.', 'L', 'Cream', '10-9.jpg', 'Numero Uno', 10),
(100000009, 'Culotte trousers with tie-waist.', 699, 'These apparels are very stylish and comfortable too.Get rid of the \'regular\' look this season wearing these kinda trousers.', 'M', 'Pink', '10-10.jpg', 'Mango', 10),
(800000010, 'Pretty print top', 799, 'This printed top with a high neckline and full sleeves makes it one of the best in wardrobe.Pair it with a black skinny jeans and slay the casual look.', 'M', 'Yellow', '8-12.jpg', 'The House of Mayra', 8);

-- --------------------------------------------------------

--
-- Table structure for table `dresscategory`
--

CREATE TABLE `dresscategory` (
  `name` varchar(50) NOT NULL,
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `dresscategory`
--

INSERT INTO `dresscategory` (`name`, `id`) VALUES
('Kurtis,Tunics and Tops', 1),
('Ethnic dresses', 2),
('Salwars and Churidars', 3),
('Skirts and Palazzos', 4),
('Sarees and Blouses', 5),
('Lehengas', 6),
('Dresses and Jumpsuits', 7),
('Tops,T-Shirts and Shirts', 8),
('Jeans and Jeggings', 9),
('Trousers and Capris', 10),
('Shorts and Skirts', 11),
('Shrugs,Jackets and Sweatshirts', 12);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `name` varchar(20) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(20) NOT NULL,
  `contact` bigint(11) NOT NULL,
  `city` varchar(30) NOT NULL,
  `address` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`name`, `email`, `password`, `contact`, `city`, `address`) VALUES
('Riya', 'mulaniriya6@gmail.com', 'riya', 9916568410, 'Shivamogga', 'Old Barline Road'),
('Palakshaiah', 'pal3362@gmail.com', 'pal', 9886693362, 'Shivamogga', 'Devaraj urs nagar '),
('Spoorthi', 'spoochoo1997@gmail.com', 'spoo', 9731331962, 'Shivamogga', 'Devaraj urs nagar '),
('Spoorthi', 'spoorthi1710@gmail.com', 'spoorthi', 9731331962, 'Shivamogga', 'Devaraj urs nagar '),
('Spoorthi chinivar', 'srchinivar@gmail.com', 'chinni', 8951799712, 'Shivamogga', 'Malleshwara nagar');

-- --------------------------------------------------------

--
-- Table structure for table `wishlist`
--

CREATE TABLE `wishlist` (
  `email` varchar(50) NOT NULL,
  `dresscode` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `wishlist`
--

INSERT INTO `wishlist` (`email`, `dresscode`) VALUES
('mulaniriya6@gmail.com', 90000001),
('mulaniriya6@gmail.com', 90000003),
('spoorthi1710@gmail.com', 11000002),
('spoorthi1710@gmail.com', 60000005),
('srchinivar@gmail.com', 20000010);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`name`);

--
-- Indexes for table `company`
--
ALTER TABLE `company`
  ADD PRIMARY KEY (`name`);

--
-- Indexes for table `dress`
--
ALTER TABLE `dress`
  ADD PRIMARY KEY (`dresscode`),
  ADD KEY `cname` (`cname`),
  ADD KEY `category_id` (`category_id`);

--
-- Indexes for table `dresscategory`
--
ALTER TABLE `dresscategory`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`email`);

--
-- Indexes for table `wishlist`
--
ALTER TABLE `wishlist`
  ADD PRIMARY KEY (`email`,`dresscode`),
  ADD KEY `dresscode` (`dresscode`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `dress`
--
ALTER TABLE `dress`
  ADD CONSTRAINT `dress_ibfk_1` FOREIGN KEY (`cname`) REFERENCES `company` (`name`),
  ADD CONSTRAINT `dress_ibfk_2` FOREIGN KEY (`category_id`) REFERENCES `dresscategory` (`id`);

--
-- Constraints for table `wishlist`
--
ALTER TABLE `wishlist`
  ADD CONSTRAINT `wishlist_ibfk_1` FOREIGN KEY (`email`) REFERENCES `users` (`email`),
  ADD CONSTRAINT `wishlist_ibfk_2` FOREIGN KEY (`dresscode`) REFERENCES `dress` (`dresscode`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
