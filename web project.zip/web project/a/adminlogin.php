<?php
$uname=$_POST['name'];
$pwd=$_POST['password'];

$pd=new PDO("mysql:hostname=localhost;dbname=square","4JN15CS103","jnnce");
$res=$pd->query("select  * from admin where name='$uname' and password='$pwd'");
if($row=$res->fetch())
{
  header("Location: ./indexadmin.html");
}
else
{
   echo "<script type=text/javascript>alert('Not authenticated');window.location.href='./adminlogin.html';</script>";
}

?>