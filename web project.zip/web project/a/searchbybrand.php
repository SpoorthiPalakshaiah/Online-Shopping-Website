<html>
<head>
<title>SquaRe</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js">
</script>
<style>
   .navbar {
  min-height: 80px;
}
body{
background-image:url("bg.jpg");
}

.navbar-brand {
  padding: 0 15px;
  height: 80px;
  line-height: 80px;
}

.navbar-toggle {
  margin-top: 23px;
  padding: 9px 10px !important;
}

@media (min-width: 768px) {
  .navbar-nav > li > a {
    /* (80px - line-height of 27px) / 2 = 26.5px */
    padding-top: 26.5px;
    padding-bottom: 26.5px;
    line-height: 27px;
  }
}
.d1{
position:fixed;
}

.carousel .item {
  height: 250px;
}

.item img {
    position: absolute;
    top: 0;
    left: 0;
    min-height: 250px;
}

.custom{
   width:45%;
   margin:0 auto;
   min-width:100px;
}
</style>
</head>
<body>
<div class="container-fluid">
<nav class="navbar" style="background-color:  #ccff99;border-color: #ccff99">
    <div class="navbar-header">
      <a class="navbar-brand" href="indexlogin.html"><img src="logo.png" alt="SquaRe,The fashion Destination" width=100 height=70 style="margin-top:5;border:2px solid black" /></a>
    </div>
 <ul class="nav navbar-nav navbar-right">
            
   
     <li>
     <div class="dropdown">
         <button class="btn dropdown-toggle" type="button" data-toggle="dropdown" style="background-color:#ccff99;margin-top:23">Account<span class="caret"></span></button>
<ul class="dropdown-menu">
  <li><form action="order.php" method="post">
  <input type="submit" name="ord" value="    My Orders" style="border:none;background-color:white"></form></li>
  <li><a href="wish.php">Wishlist</a></li>
  <li><form action="addtocart.php" method="post">
  <input type="submit" name="cart" value="    My Cart" style="border:none;background-color:white"></form></li>
</ul>
</div>
     </li>
      <li style="margin-right:20"><form action="addtocart.php" method="post"><input type="submit" style="color:black;border:none;background-color:#ccff99;margin-top:28;margin-right:20" name="logout" value="Logout"></form></li>
</ul>   


</nav>
</div>
<?php
if(isset($_POST['Jules'])){
$cname=$_POST['Jules'];
$pd=new PDO("mysql:hostname=localhost;dbname=square","4JN15CS103","jnnce");

$res=$pd->query("select distinct name,dresscode,price,description,size,color,cname from dress where cname='$cname'");
$st=" ";
while($row=$res->fetch())
{
 $name=$row['name'];
 $code=$row['dresscode'];
 $cost=$row['price'];
 $desc=$row['description'];
 $size=$row['size'];
 $color=$row['color'];
 $cname=$row['cname'];
  $st=$st."<div class='col-sm-4'><button style='border:none;'>
<div class='thumbnail'>
<img src=$code.jpg style='height:50%;width:80%'>
<div class='caption'><h3>'$name'</h3><h3>Price:$cost</h3>
<h4>Size:$size</h4>
<h4>Brand:$cname</h4>
<p style='height:20%;'>$desc</p>
<form action='addtocart.php?code=$code' method='POST'>
<input type='submit' id='b2' name='b2' value='Add to Cart' style='background-color:#99c2ff'></form><form action='wishlist.php?code=$code' method='POST'><input type='submit' id='b3' name='b3' value='Add to wishlist' style='background-color:#99c2ff'></form>
</div></div></button></div>";


}
echo $st;


}

if(isset($_POST['Provogue'])){
$cname=$_POST['Provogue'];
$pd=new PDO("mysql:hostname=localhost;dbname=square","4JN15CS103","jnnce");

$res=$pd->query("select distinct name,dresscode,price,description,size,color,cname from dress where cname='$cname'");
$st=" ";
while($row=$res->fetch())
{
 $name=$row['name'];
 $code=$row['dresscode'];
 $cost=$row['price'];
 $desc=$row['description'];
 $size=$row['size'];
 $color=$row['color'];
 $cname=$row['cname'];
  $st=$st."<div class='col-sm-4'><button style='border:none;'>
<div class='thumbnail'>
<img src=$code.jpg style='height:50%;width:80%'>
<div class='caption'><h3>'$name'</h3><h3>Price:$cost</h3>
<h4>Size:$size</h4>
<h4>Brand:$cname</h4>
<p style='height:20%;'>$desc</p>
<form action='addtocart.php?code=$code' method='POST'>
<input type='submit' id='b2' name='b2' value='Add to Cart' style='background-color:#99c2ff'></form><form action='wishlist.php?code=$code' method='POST'><input type='submit' id='b3' name='b3' value='Add to wishlist' style='background-color:#99c2ff'></form>
</div></div></button></div>";


}
echo $st;


}


if(isset($_POST['Mango'])){
$cname=$_POST['Mango'];
$pd=new PDO("mysql:hostname=localhost;dbname=square","4JN15CS103","jnnce");

$res=$pd->query("select distinct name,dresscode,price,description,size,color,cname from dress where cname='$cname'");
$st=" ";
while($row=$res->fetch())
{
 $name=$row['name'];
 $code=$row['dresscode'];
 $cost=$row['price'];
 $desc=$row['description'];
 $size=$row['size'];
 $color=$row['color'];
 $cname=$row['cname'];
  $st=$st."<div class='col-sm-4'><button style='border:none;'>
<div class='thumbnail'>
<img src=$code.jpg style='height:50%;width:80%'>
<div class='caption'><h3>'$name'</h3><h3>Price:$cost</h3>
<h4>Size:$size</h4>
<h4>Brand:$cname</h4>
<p style='height:20%;'>$desc</p>
<form action='addtocart.php?code=$code' method='POST'>
<input type='submit' id='b2' name='b2' value='Add to Cart' style='background-color:#99c2ff'></form><form action='wishlist.php?code=$code' method='POST'><input type='submit' id='b3' name='b3' value='Add to wishlist' style='background-color:#99c2ff'></form>
</div></div></button></div>";


}
echo $st;


}


if(isset($_POST['Zara'])){
$cname=$_POST['Zara'];
$pd=new PDO("mysql:hostname=localhost;dbname=square","4JN15CS103","jnnce");

$res=$pd->query("select distinct name,dresscode,price,description,size,color,cname from dress where cname='$cname'");
$st=" ";
while($row=$res->fetch())
{
 $name=$row['name'];
 $code=$row['dresscode'];
 $cost=$row['price'];
 $desc=$row['description'];
 $size=$row['size'];
 $color=$row['color'];
 $cname=$row['cname'];
  $st=$st."<div class='col-sm-4'><button style='border:none;'>
<div class='thumbnail'>
<img src=$code.jpg style='height:50%;width:80%'>
<div class='caption'><h3>'$name'</h3><h3>Price:$cost</h3>
<h4>Size:$size</h4>
<h4>Brand:$cname</h4>
<p style='height:20%;'>$desc</p>
<form action='addtocart.php?code=$code' method='POST'>
<input type='submit' id='b2' name='b2' value='Add to Cart' style='background-color:#99c2ff'></form><form action='wishlist.php?code=$code' method='POST'><input type='submit' id='b3' name='b3' value='Add to wishlist' style='background-color:#99c2ff'></form>
</div></div></button></div>";


}
echo $st;


}


if(isset($_POST['Roadster'])){
$cname=$_POST['Roadster'];
$pd=new PDO("mysql:hostname=localhost;dbname=square","4JN15CS103","jnnce");

$res=$pd->query("select distinct name,dresscode,price,description,size,color,cname from dress where cname='$cname'");
$st=" ";
while($row=$res->fetch())
{
 $name=$row['name'];
 $code=$row['dresscode'];
 $cost=$row['price'];
 $desc=$row['description'];
 $size=$row['size'];
 $color=$row['color'];
 $cname=$row['cname'];
  $st=$st."<div class='col-sm-4'><button style='border:none;'>
<div class='thumbnail'>
<img src=$code.jpg style='height:50%;width:80%'>
<div class='caption'><h3>'$name'</h3><h3>Price:$cost</h3>
<h4>Size:$size</h4>
<h4>Brand:$cname</h4>
<p style='height:20%;'>$desc</p>
<form action='addtocart.php?code=$code' method='POST'>
<input type='submit' id='b2' name='b2' value='Add to Cart' style='background-color:#99c2ff'></form><form action='wishlist.php?code=$code' method='POST'><input type='submit' id='b3' name='b3' value='Add to wishlist' style='background-color:#99c2ff'></form>
</div></div></button></div>";


}
echo $st;


}

if(isset($_POST['Dressberry'])){
$cname=$_POST['Dressberry'];
$pd=new PDO("mysql:hostname=localhost;dbname=square","4JN15CS103","jnnce");

$res=$pd->query("select distinct name,dresscode,price,description,size,color,cname from dress where cname='$cname'");
$st=" ";
while($row=$res->fetch())
{
 $name=$row['name'];
 $code=$row['dresscode'];
 $cost=$row['price'];
 $desc=$row['description'];
 $size=$row['size'];
 $color=$row['color'];
 $cname=$row['cname'];
  $st=$st."<div class='col-sm-4'><button style='border:none;'>
<div class='thumbnail'>
<img src=$code.jpg style='height:50%;width:80%'>
<div class='caption'><h3>'$name'</h3><h3>Price:$cost</h3>
<h4>Size:$size</h4>
<h4>Brand:$cname</h4>
<p style='height:20%;'>$desc</p>
<form action='addtocart.php?code=$code' method='POST'>
<input type='submit' id='b2' name='b2' value='Add to Cart' style='background-color:#99c2ff'></form><form action='wishlist.php?code=$code' method='POST'><input type='submit' id='b3' name='b3' value='Add to wishlist' style='background-color:#99c2ff'></form>
</div></div></button></div>";


}
echo $st;
}

?>