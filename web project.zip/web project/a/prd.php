<?php
$name=$_GET['name'];

$pd=new PDO("mysql:hostname=localhost;dbname=square","4JN15CS103","jnnce");

$res=$pd->query("select distinct dress.name,dresscode,price,description,size,color,cname from dress join dresscategory on dress.category_id=(Select id from dresscategory where name='$name')");
$st="";
while($row=$res->fetch())
{
 $name=$row['name'];
 $code=$row['dresscode'];
 $cost=$row['price'];
 $desc=$row['description'];
 $size=$row['size'];
 $color=$row['color'];
 $cname=$row['cname'];
  $st=$st."<div class='col-sm-4'>
<button id='b1' name='b1' style='border:none'>
<div class='thumbnail'>
<img src=$code.jpg style='height:50%;width:80%'>
<div class='caption'><h3>'$name'</h3><h3>Price:$cost</h3>
<h4>Size:$size</h4>
<h4>Brand:$cname</h4>
<p style='height:20%;'>$desc</p>
<form action='addtocart.php?code=$code' method='POST'>
<input type='submit' id='b2' name='b2' value='Add to Cart' style='background-color:#99c2ff'></form><form action='wishlist.php?code=$code' method='POST'><input type='submit' id='b3' name='b3' value='Add to wishlist' style='background-color:#99c2ff'></form></div></div></button></div>";


}
echo $st;
?>





