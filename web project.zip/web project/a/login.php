<?php
$uname=$_POST['email'];
$pwd=$_POST['password'];
$email="email";
setcookie($email, $uname, time() + (86400 * 30), "/");
$pd=new PDO("mysql:hostname=localhost;dbname=square","4JN15CS103","jnnce");
$res=$pd->query("select  * from users where email='$uname' and password='$pwd'");
if($row=$res->fetch())
{
  header("Location:./indexlogin.html");
}
else
{
echo "<script type=text/javascript>alert('Invalid username or password');window.location.href='./login.html';</script>";
}

?>