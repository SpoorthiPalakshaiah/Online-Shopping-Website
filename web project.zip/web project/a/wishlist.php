<?php
$code=$_GET['code'];
if(isset($_POST['b3'])){
$arr=$_COOKIE['email'];
$pd=new PDO("mysql:hostname=localhost;dbname=square","4JN15CS103","jnnce");

$res=$pd->query("insert into wishlist values('$arr',$code)");
if(!$res->fetch()){
echo "<script type=text/javascript>alert('Added to wishlist successfully');window.location.href='./indexlogin.html';</script>";
}
}
?>