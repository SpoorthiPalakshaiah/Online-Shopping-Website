<html>
<head>
<title>SquaRe</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js">
</script>
<style>
   .navbar {
  min-height: 80px;
}
body{
background-image:url("bg.jpg");
}

.navbar-brand {
  padding: 0 15px;
  height: 80px;
  line-height: 80px;
}

.navbar-toggle {
  margin-top: 23px;
  padding: 9px 10px !important;
}

@media (min-width: 768px) {
  .navbar-nav > li > a {
    /* (80px - line-height of 27px) / 2 = 26.5px */
    padding-top: 26.5px;
    padding-bottom: 26.5px;
    line-height: 27px;
  }
}
.d1{
position:fixed;
}

.carousel .item {
  height: 250px;
}

.item img {
    position: absolute;
    top: 0;
    left: 0;
    min-height: 250px;
}

.custom{
   width:45%;
   margin:0 auto;
   min-width:100px;
}
</style>
</head>
<body>
<div class="container-fluid">
<nav class="navbar" style="background-color:  #ccff99;border-color: #ccff99">
    <div class="navbar-header">
      <a class="navbar-brand" href=#><img src="logo.png" alt="SquaRe,The fashion Destination" width=100 height=70 style="margin-top:5;border:2px solid black" /></a>
    </div>
    <ul class="nav navbar-nav navbar-right">

   
      <li style="margin-right:20"><form action="index.html" method="post"><input type="submit" style="color:black;border:none;background-color:#ccff99;margin-top:28;margin-right:20" name="logout" value="Logout"></form></li>
</ul>
</nav>
</div>
        <div class="container">
            <div class="jumbotron">
                <h1>Your Order is Confirmed!</h1>
                <h3>Thank you for shopping with us!!</h3>
                           </div>
        </div>

<?php
$data=$_GET['data'];
$arr=explode(" ",$data);
foreach($arr as $a){
$mail=$_COOKIE['email'];
$code=$a;
$pd=new PDO("mysql:hostname=localhost;dbname=square","4JN15CS103","jnnce");
$res=$pd->query("insert into buy values('$mail',$code,'Successful')");
}
?>