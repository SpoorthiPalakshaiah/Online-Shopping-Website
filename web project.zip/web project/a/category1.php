<?php
if(isset($_POST['update'])){

$id=$_POST['id'];
$name=$_POST['name'];
$updatename=$_POST['updatedname'];
$pd=new PDO("mysql:hostname=localhost;dbname=square","4JN15CS103","jnnce");
$res=$pd->query("Select * from dresscategory where id='$id'");
if(!$res->fetch()){
echo "<script type=text/javascript>alert('Category doesnot exists');window.location.href='./category.html';</script>";
}
else{

$res=$pd->query("update dresscategory set name='$updatename' where id=$id");
echo "<script type=text/javascript>alert('Updated successfully');window.location.href='./category.html';</script>";

}
}




?>