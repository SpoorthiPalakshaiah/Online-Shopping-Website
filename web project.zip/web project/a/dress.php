<?php
ini_set('display_errors','0');
if(isset($_POST['updatename'])){
$code=$_POST['code'];
$name=$_POST['updatedname'];
$pd=new PDO("mysql:hostname=localhost;dbname=square","4JN15CS103","jnnce");
$res=$pd->query("Select * from dress where dresscode=$code");
if(!$res->fetch()){
echo "<script type=text/javascript>alert('Dress doesnot exists')</script>";
}
else{

$res=$pd->query("update dress set name='$name' where dresscode=$code");
echo "<script type=text/javascript>alert('Updated successfully')</script>";

}
}

if(isset($_POST['updateprice'])){
$code=$_POST['code'];
$price=$_POST['updatedprice'];
$pd=new PDO("mysql:hostname=localhost;dbname=square","4JN15CS103","jnnce");
$res=$pd->query("Select * from dress where dresscode=$code");
if(!$res->fetch()){
echo "<script type=text/javascript>alert('Dress doesnot exists')</script>";
}
else{

$res=$pd->query("update dress set price='$price' where dresscode=$code");
echo "<script type=text/javascript>alert('Updated successfully')</script>";

}
}

if(isset($_POST['updatedescription'])){
$code=$_POST['code'];
$desc=$_POST['updateddescription'];
$pd=new PDO("mysql:hostname=localhost;dbname=square","4JN15CS103","jnnce");
$res=$pd->query("Select * from dress where dresscode=$code");
if(!$res->fetch()){
echo "<script type=text/javascript>alert('Dress doesnot exists')</script>";
}
else{

$res=$pd->query("update dress set description='$desc' where dresscode=$code");
echo "<script type=text/javascript>alert('Updated successfully')</script>";

}
}

if(isset($_POST['updatesize'])){
$code=$_POST['code'];
$size=$_POST['updatedsize'];
$pd=new PDO("mysql:hostname=localhost;dbname=square","4JN15CS103","jnnce");
$res=$pd->query("Select * from dress where dresscode=$code");
if(!$res->fetch()){
echo "<script type=text/javascript>alert('Dress doesnot exists')</script>";
}
else{

$res=$pd->query("update dress set size='$size' where dresscode=$code");
echo "<script type=text/javascript>alert('Updated successfully')</script>";

}
}

if(isset($_POST['updatecolor'])){
$code=$_POST['code'];
$color=$_POST['updatedcolor'];
$pd=new PDO("mysql:hostname=localhost;dbname=square","4JN15CS103","jnnce");
$res=$pd->query("Select * from dress where dresscode=$code");
if(!$res->fetch()){
echo "<script type=text/javascript>alert('Dress doesnot exists')</script>";
}
else{

$res=$pd->query("update dress set color='$color' where dresscode=$code");
echo "<script type=text/javascript>alert('Updated successfully')</script>";

}
}

if(isset($_POST['delete'])){
$code=$_POST['code'];
$pd=new PDO("mysql:hostname=localhost;dbname=square","4JN15CS103","jnnce");
$res=$pd->query("Select * from dress where dresscode=$code");
if(!$res->fetch()){
echo "<script type=text/javascript>alert('Dress doesnot exists')</script>";
}
else{

$res=$pd->query("delete from dress where dresscode=$code");
echo "<script type=text/javascript>alert('Deleted successfully')</script>";

}
}


if(isset($_POST['insert']))
{
$code=$_POST['code'];
$name=$_POST['name'];
$price=$_POST['price'];
$desc=$_POST['description'];
$size=$_POST['size'];
$colr=$_POST['color'];
$cn=$_POST['s1'];
$cid=$_POST['s2'];
$pd=new PDO("mysql:hostname=localhost;dbname=square","4JN15CS103","jnnce");
$res=$pd->query("select  * from dress where dresscode=$code");
if($row=$res->fetch())
{
   echo "<script type=text/javascript>alert('Dress already exists')</script>";
  
}

$fname=$_FILES['f1']['name'];

$ext=explode(".",$fname);
$arr=array("jpg","jpeg","png","JPG","JPEG","PNG");
if(!in_array($ext[1],$arr))
{
   echo "<script type=text/javascript>alert('Invalid file format') </script>";
}
else
{
 

 $dest=$code.".".$ext[1];
$src=$_FILES['f1']['tmp_name'];
if(move_uploaded_file($src,$dest)<0)
{
    echo "<script type=text/javascript>alert('Error in File Upload')</script>";
}
else
{
  echo "<script type=text/javascript>alert('File uploaded successfully')</script>";
  




$pd->query("insert into dress values($code,'$name','$price','$desc','$size','$colr','$fname','$cn','$cid')");
echo "<script type=text/javascript>alert('Dress added successfully')</script>";
  
}
}
}
?>

<!DOCTYPE html5>
<html>
<head>
<title>SquaRe</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js">
</script>
<style>
   .navbar {
  min-height: 80px;
}
body{
background-image:url("bg.jpg");
}

.navbar-brand {
  padding: 0 15px;
  height: 80px;
  line-height: 80px;
}

.navbar-toggle {
  margin-top: 23px;
  padding: 9px 10px !important;
}

@media (min-width: 768px) {
  .navbar-nav > li > a {
    /* (80px - line-height of 27px) / 2 = 26.5px */
    padding-top: 26.5px;
    padding-bottom: 26.5px;
    line-height: 27px;
  }
}
.d1{
position:fixed;
}


.item img {
    position: absolute;
    top: 0;
    left: 0;
    min-height: 250px;
}

.custom{
   width:45%;
   margin:0 auto;
   min-width:100px;
}
</style>
</head>
<body>
<div class="container-fluid" id="d1">
<nav class="navbar" style="background-color:  #ccff99;border-color: #ccff99">
    <div class="navbar-header">
      <a class="navbar-brand" href=".\indexadmin.html"><img src="logo.png" alt="SquaRe,The fashion Destination" width=100 height=70 style="margin-top:5;border:2px solid black" /></a>
    </div>
    
    <ul class="nav navbar-nav navbar-right">
   <li><a href=".\category.html"  style="color:black">Category</a></li>
<li><a href=".\company.html"  style="color:black">Company</a></li>
<li><a href=".\dress.php"  style="color:black">Dress</a></li>



<li style="margin-right:20"><a href=".\index.html" style="color:black"><span class="glyphicon glyphicon-log-in"  style="color:black"></span> Logout</a></li>
</ul></div>
<div class="container" style="margin-left:300">

<div class="panel panel-success custom" style="margin-top:50;float:left">
<div class="panel-heading"><center>Insert,update or delete Dress Details</center>
</div>
<div class="panel-body">
<?php
 echo "<form action='dress.php' method='POST' enctype='multipart/form-data'>";
?>
Dresscode:<br>
<input class="col-sm-12" type="number" name="code" required><br>
Name:&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp Name to be updated as:<br>
<input class="col-sm-4" type="text" name="name">
<input class="col-sm-4" type="text" name="updatedname" style="margin-left:10;margin-right:10">
<button class="btn-success" type="submit" name="updatename">Update</button>
<br>
Price:&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp Price to be updated as:<br>
<input class="col-sm-4" type="text" name="price">
<input class="col-sm-4" type="text" name="updatedprice" style="margin-left:10;margin-right:10">
<button class="btn-success" type="submit" name="updateprice">Update</button>
<br>
Description:&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp Description to be updated as:<br>
<textarea rows="4" cols="16" name="description"></textarea>
<textarea rows="4" cols="16" name="updateddescription"style="margin-left:10;margin-right:10"></textarea>
 
<button class="btn-success" type="submit" name="updatedescription">Update</button>
<br>

Size:&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp Size to be updated as:<br>
<input class="col-sm-4" type="text" name="size">
<input class="col-sm-4" type="text" name="updatedsize" style="margin-left:10;margin-right:10">
<button class="btn-success" type="submit" name="updatesize">Update</button>
<br>

Color:&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp Color to be updated as:<br>
<input class="col-sm-4" type="text" name="color">
<input class="col-sm-4" type="text" name="updatedcolor" style="margin-left:10;margin-right:10">
<button class="btn-success" type="submit" name="updatecolor">Update</button>
<br>
<br>



Image:<input type="file" name="f1" id="f1">


<div class="form-group">
<label class="control-label col-sm-4" for="sell">Brand Name:</label>
<div class="col-sm-10">
<select class="form-control" id="sell" name="s1">
<?php
$pd=new PDO("mysql:hostname=localhost;dbname=square","4JN15CS103","jnnce");
$res=$pd->query("Select name from company");
while($row=$res->fetch())
{
   $name=$row['name'];
   echo "<option>$name</option>";
}
?>
</select>
</div>
</div>
<div class="form-group">
<label class="control-label col-sm-4" for="sell1">Category ID:</label>
<div class="col-sm-10">
<select class="form-control" id="sell1" name="s2">
<?php
$pd=new PDO("mysql:hostname=localhost;dbname=square","4JN15CS103","jnnce");
$res=$pd->query("Select id from dresscategory");
while($row=$res->fetch())
{
   $id=$row['id'];
   echo "<option>$id</option>";
}

?>
</select>
</div>
</div>

<div class="col-sm-6">
<button class="btn-success" type="submit" name="insert">Insert</button></div>
<div class="col-sm-6">
<button class="btn-success" type="submit" name="delete">Delete</button>
</div>
</form>
</div>
</div>
</body>
</html>









