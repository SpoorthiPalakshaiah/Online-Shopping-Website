<?php
if(isset($_POST['insert'])){

$id=$_POST['id'];
$name=$_POST['name'];

$pd=new PDO("mysql:hostname=localhost;dbname=square","4JN15CS103","jnnce");
$res=$pd->query("Select * from dresscategory where id='$id'");
if($res->fetch()){
echo "<script type=text/javascript>alert('Category already exists')</script>";
}
else if($id==NULL||$name==NULL){
echo "<script type=text/javascript>alert('Cannot be inserted');window.location.href='./category.html';</script>";
}
else{

$res=$pd->query("insert into dresscategory values('$name',$id)");
echo "<script type=text/javascript>alert('Successfully inserted');window.location.href='./category.html';</script>";

}
}

if(isset($_POST['delete'])){

$id=$_POST['id'];
$name=$_POST['name'];
$pd=new PDO("mysql:hostname=localhost;dbname=square","4JN15CS103","jnnce");
$res=$pd->query("Select * from dresscategory where id='$id'");
$res1=$pd->query("Select distinct category_id from dress");
$arr=array();
while($row=$res1->fetch())
{
  $id=$row['category_id'];
  array_push($arr,$id);
}

if(!$res->fetch()){
echo "<script type=text/javascript>alert('Category doesnot exists');window.location.href='./category.html';</script>";
}
else if(in_array($id,$arr)){
    echo "<script type=text/javascript>alert('Category cannot be deleted');window.location.href='./category.html';</script>";
}


else{
$res=$pd->query("delete from dresscategory where id='$id'");
echo "<script type=text/javascript>alert('Successfully deleted');window.location.href='./category.html';</script>";
}

}


?>