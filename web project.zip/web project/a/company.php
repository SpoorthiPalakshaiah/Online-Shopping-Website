<?php
if(isset($_POST['insert'])){

$name=$_POST['name'];
$contact=$_POST['contact'];
$address=$_POST['address'];

$pd=new PDO("mysql:hostname=localhost;dbname=square","4JN15CS103","jnnce");
$res=$pd->query("Select * from company where name='$name'");
if($res->fetch()){
echo "<script type=text/javascript>alert('Company name already exists');window.location.href='./company.html';</script>";
}
else if($name==NULL||$contact==NULL||$address==NULL){
echo "<script type=text/javascript>alert('Cannot be inserted');window.location.href='./company.html';</script>";
}
else{

$res=$pd->query("insert into company values('$name',$contact,'$address')");
echo "<script type=text/javascript>alert('Successfully inserted');window.location.href='./company.html';</script>";

}
}

if(isset($_POST['delete'])){

$name=$_POST['name'];
$contact=$_POST['contact'];
$address=$_POST['address'];

$pd=new PDO("mysql:hostname=localhost;dbname=square","4JN15CS103","jnnce");
$res=$pd->query("Select * from company where name='$name'");
if(!$res->fetch()){
echo "<script type=text/javascript>alert('Company doesnot exists');window.location.href='./company.html';</script>";
}
else{

$res=$pd->query("delete from company where name='$name'");
echo "<script type=text/javascript>alert('Successfully deleted');window.location.href='./company.html';</script>";

}
}

if(isset($_POST['updatecontact'])){

$name=$_POST['name'];
$contact=$_POST['contact'];
$updatedcontact=$_POST['updatedcontact'];
$address=$_POST['address'];
$pd=new PDO("mysql:hostname=localhost;dbname=square","4JN15CS103","jnnce");
$res=$pd->query("Select * from company where name='$name'");
if(!$res->fetch()){
echo "<script type=text/javascript>alert('Company doesnot exists');window.location.href='./company.html';</script>";
}
else{

$res=$pd->query("update company set phoneno=$updatedcontact where name='$name'");
echo "<script type=text/javascript>alert('Updated contact successfully');window.location.href='./company.html';</script>";

}
}

if(isset($_POST['updateaddress'])){

$name=$_POST['name'];
$contact=$_POST['contact'];
$updatedaddress=$_POST['updatedaddress'];
$address=$_POST['address'];
$pd=new PDO("mysql:hostname=localhost;dbname=square","4JN15CS103","jnnce");
$res=$pd->query("Select * from company where name='$name'");
if(!$res->fetch()){
echo "<script type=text/javascript>alert('Company doesnot exists');window.location.href='./company.html';</script>";
}
else{

$res=$pd->query("update company set address='$updatedaddress' where name='$name'");
echo "<script type=text/javascript>alert('Updated address successfully');window.location.href='./company.html';</script>";

}
}


?>