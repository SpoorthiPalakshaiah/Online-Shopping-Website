<html>
<head>
<title>SquaRe</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js">
</script>
<style>
   .navbar {
  min-height: 80px;
}
body{
background-image:url("bg.jpg");
}

.navbar-brand {
  padding: 0 15px;
  height: 80px;
  line-height: 80px;
}

.navbar-toggle {
  margin-top: 23px;
  padding: 9px 10px !important;
}

@media (min-width: 768px) {
  .navbar-nav > li > a {
    /* (80px - line-height of 27px) / 2 = 26.5px */
    padding-top: 26.5px;
    padding-bottom: 26.5px;
    line-height: 27px;
  }
}
.d1{
position:fixed;
}

.carousel .item {
  height: 250px;
}

.item img {
    position: absolute;
    top: 0;
    left: 0;
    min-height: 250px;
}

.custom{
   width:45%;
   margin:0 auto;
   min-width:100px;
}
</style>
</head>
<body>
<div class="container-fluid">
<nav class="navbar" style="background-color:  #ccff99;border-color: #ccff99">
    <div class="navbar-header">
      <a class="navbar-brand" href="index.html"><img src="logo.png" alt="SquaRe,The fashion Destination" width=100 height=70 style="margin-top:5;border:2px solid black" /></a>
    </div>
   
</nav>
</div>
<?php
if(isset($_POST['red'])){
$color=$_POST['red'];
$pd=new PDO("mysql:hostname=localhost;dbname=square","4JN15CS103","jnnce");

$res=$pd->query("select distinct name,dresscode,price,description,size,color,cname from dress where color='$color'");
$st=" ";
while($row=$res->fetch())
{
 $name=$row['name'];
 $code=$row['dresscode'];
 $cost=$row['price'];
 $desc=$row['description'];
 $size=$row['size'];
 $color=$row['color'];
 $cname=$row['cname'];
  $st=$st."<div class='col-sm-4'><button style='border:none;'>
<div class='thumbnail'>
<img src=$code.jpg style='height:50%;width:80%'>
<div class='caption'><h3>'$name'</h3><h3>Price:$cost</h3>
<h4>Size:$size</h4>
<h4>Brand:$cname</h4>
<p style='height:20%;'>$desc</p>
<form action='login.html'>
<input type='submit' value='Login to Shop' style='border:none;background-color:#99c2ff'>
</form>
</div></div></button></div>";


}
echo $st;


}

if(isset($_POST['black'])){
$color=$_POST['black'];
$pd=new PDO("mysql:hostname=localhost;dbname=square","4JN15CS103","jnnce");

$res=$pd->query("select distinct name,dresscode,price,description,size,color,cname from dress where color='$color'");
$st=" ";
while($row=$res->fetch())
{
 $name=$row['name'];
 $code=$row['dresscode'];
 $cost=$row['price'];
 $desc=$row['description'];
 $size=$row['size'];
 $color=$row['color'];
 $cname=$row['cname'];
  $st=$st."<div class='col-sm-4'><button style='border:none;'>
<div class='thumbnail'>
<img src=$code.jpg style='height:50%;width:80%'>
<div class='caption'><h3>'$name'</h3><h3>Price:$cost</h3>
<h4>Size:$size</h4>
<h4>Brand:$cname</h4>
<p style='height:20%;'>$desc</p>
<form action='login.html'>
<input type='submit' value='Login to Shop' style='border:none;background-color:#99c2ff'>
</form>
</div></div></button></div>";


}
echo $st;


}


if(isset($_POST['white'])){
$color=$_POST['white'];
$pd=new PDO("mysql:hostname=localhost;dbname=square","4JN15CS103","jnnce");

$res=$pd->query("select distinct name,dresscode,price,description,size,color,cname from dress where color='$color'");
$st=" ";
while($row=$res->fetch())
{
 $name=$row['name'];
 $code=$row['dresscode'];
 $cost=$row['price'];
 $desc=$row['description'];
 $size=$row['size'];
 $color=$row['color'];
 $cname=$row['cname'];
  $st=$st."<div class='col-sm-4'><button style='border:none;'>
<div class='thumbnail'>
<img src=$code.jpg style='height:50%;width:80%'>
<div class='caption'><h3>'$name'</h3><h3>Price:$cost</h3>
<h4>Size:$size</h4>
<h4>Brand:$cname</h4>
<p style='height:20%;'>$desc</p>
<form action='login.html'>
<input type='submit' value='Login to Shop' style='border:none;background-color:#99c2ff'>
</form>
</div></div></button></div>";


}
echo $st;


}


if(isset($_POST['blue'])){
$color=$_POST['blue'];
$pd=new PDO("mysql:hostname=localhost;dbname=square","4JN15CS103","jnnce");

$res=$pd->query("select distinct name,dresscode,price,description,size,color,cname from dress where color='$color'");
$st=" ";
while($row=$res->fetch())
{
 $name=$row['name'];
 $code=$row['dresscode'];
 $cost=$row['price'];
 $desc=$row['description'];
 $size=$row['size'];
 $color=$row['color'];
 $cname=$row['cname'];
  $st=$st."<div class='col-sm-4'><button style='border:none;'>
<div class='thumbnail'>
<img src=$code.jpg style='height:50%;width:80%'>
<div class='caption'><h3>'$name'</h3><h3>Price:$cost</h3>
<h4>Size:$size</h4>
<h4>Brand:$cname</h4>
<p style='height:20%;'>$desc</p>
<form action='login.html'>
<input type='submit' value='Login to Shop' style='border:none;background-color:#99c2ff'>
</form>
</div></div></button></div>";


}
echo $st;


}


if(isset($_POST['green'])){
$color=$_POST['green'];
$pd=new PDO("mysql:hostname=localhost;dbname=square","4JN15CS103","jnnce");

$res=$pd->query("select distinct name,dresscode,price,description,size,color,cname from dress where color='$color'");
$st=" ";
while($row=$res->fetch())
{
 $name=$row['name'];
 $code=$row['dresscode'];
 $cost=$row['price'];
 $desc=$row['description'];
 $size=$row['size'];
 $color=$row['color'];
 $cname=$row['cname'];
  $st=$st."<div class='col-sm-4'><button style='border:none;'>
<div class='thumbnail'>
<img src=$code.jpg style='height:50%;width:80%'>
<div class='caption'><h3>'$name'</h3><h3>Price:$cost</h3>
<h4>Size:$size</h4>
<h4>Brand:$cname</h4>
<p style='height:20%;'>$desc</p>
<form action='login.html'>
<input type='submit' value='Login to Shop' style='border:none;background-color:#99c2ff'>
</form>
</div></div></button></div>";


}
echo $st;


}

if(isset($_POST['cream'])){
$color=$_POST['cream'];
$pd=new PDO("mysql:hostname=localhost;dbname=square","4JN15CS103","jnnce");

$res=$pd->query("select distinct name,dresscode,price,description,size,color,cname from dress where color='$color'");
$st=" ";
while($row=$res->fetch())
{
 $name=$row['name'];
 $code=$row['dresscode'];
 $cost=$row['price'];
 $desc=$row['description'];
 $size=$row['size'];
 $color=$row['color'];
 $cname=$row['cname'];
  $st=$st."<div class='col-sm-4'><button style='border:none;'>
<div class='thumbnail'>
<img src=$code.jpg style='height:50%;width:80%'>
<div class='caption'><h3>'$name'</h3><h3>Price:$cost</h3>
<h4>Size:$size</h4>
<h4>Brand:$cname</h4>
<p style='height:20%;'>$desc</p>
<form action='login.html'>
<input type='submit' value='Login to Shop' style='border:none;background-color:#99c2ff'>
</form>
</div></div></button></div>";


}
echo $st;
}

?>