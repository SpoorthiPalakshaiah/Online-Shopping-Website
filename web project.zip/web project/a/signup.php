<?php
$name=$_POST['name'];
$email=$_POST['email'];
$password=$_POST['password'];
$contact=$_POST['contact'];
$city=$_POST['city'];
$address=$_POST['address'];

$pd=new PDO("mysql:hostname=localhost;dbname=square","4JN15CS103","jnnce");
$res=$pd->query("Select * from users where email='$email'");
if($res->fetch()){
echo "<script type=text/javascript>alert('Email already registered');window.location.href='./signup.html';</script>";
}
else if($name==NULL||$email==NULL||$password==NULL||$contact==NULL||$city==NULL||$address==NULL){
echo "<script type=text/javascript>alert('Fill all the fields');window.location.href='./signup.html';</script>";

}
else{
$res=$pd->query("insert into users(name,email,password,contact,city,address)  values('$name','$email','$password','$contact','$city','$address')");
echo "<script type=text/javascript>alert('Successfully Registered');window.location.href='./login.html';</script>";

}
?>